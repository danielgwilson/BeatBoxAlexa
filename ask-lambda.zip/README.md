# BeatBoxAlexa
![Build](https://img.shields.io/badge/build-passing-brightgreen.svg "Build")
![License](https://img.shields.io/badge/license-MIT-blue.svg "License")

Alexa back up another echo. Check it out! Developed at TreeHacks 2016!

## Credits
- [ask-alexa-pykit](https://github.com/anjishnu/ask-alexa-pykit)

## Todos:
- Set up for demo with correct timings
